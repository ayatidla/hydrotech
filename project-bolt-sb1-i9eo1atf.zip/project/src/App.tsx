import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { UserProfileForm } from './components/UserProfileForm';
import { HydrationDashboard } from './components/HydrationDashboard';
import { BottleControls } from './components/BottleControls';
import { Analytics } from './components/Analytics';
import { useLocalStorage } from './hooks/useLocalStorage';
import { UserProfile, HydrationRecord, BottleStatus, NotificationSettings } from './types';
import { Droplets } from 'lucide-react';

// Mock bottle status - in a real app, this would come from the smart bottle
const mockBottleStatus: BottleStatus = {
  waterLevel: 75,
  temperature: 22,
  batteryLevel: 85,
  isConnected: true
};

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [profile, setProfile] = useLocalStorage<UserProfile | null>('hydrotech-profile', null);
  const [records, setRecords] = useLocalStorage<HydrationRecord[]>('hydrotech-records', []);
  const [bottleStatus, setBottleStatus] = useState<BottleStatus>(mockBottleStatus);
  const [notificationSettings, setNotificationSettings] = useLocalStorage<NotificationSettings>(
    'hydrotech-notifications',
    {
      reminderInterval: 60,
      soundEnabled: true,
      lcdNotifications: true,
      personalizedMessages: true
    }
  );

  // Simulate bottle status updates
  useEffect(() => {
    const interval = setInterval(() => {
      setBottleStatus(prev => ({
        ...prev,
        temperature: Math.round((prev.temperature + (Math.random() - 0.5) * 2) * 10) / 10,
        waterLevel: Math.max(0, prev.waterLevel - Math.random() * 2),
        batteryLevel: Math.max(0, prev.batteryLevel - 0.1)
      }));
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  // Set up hydration reminders
  useEffect(() => {
    if (!profile || !notificationSettings.soundEnabled) return;

    const interval = setInterval(() => {
      const now = new Date();
      const today = now.toDateString();
      const todayRecords = records.filter(record => 
        new Date(record.timestamp).toDateString() === today
      );
      const todayConsumption = todayRecords.reduce((sum, record) => sum + record.amount, 0);
      
      if (todayConsumption < profile.dailyGoal) {
        // In a real app, this would trigger a notification
        console.log('Hydration reminder: Time to drink some water!');
        
        // Play notification sound (mock)
        if (notificationSettings.soundEnabled) {
          console.log('🔔 Playing reminder sound');
        }
        
        // Send LCD notification (mock)
        if (notificationSettings.lcdNotifications) {
          console.log('📱 Sending LCD notification to bottle');
        }
      }
    }, notificationSettings.reminderInterval * 60 * 1000);

    return () => clearInterval(interval);
  }, [profile, records, notificationSettings]);

  const handleAddWater = (amount: number) => {
    const newRecord: HydrationRecord = {
      id: Date.now().toString(),
      timestamp: new Date(),
      amount,
      temperature: bottleStatus.temperature
    };
    
    setRecords(prev => [...prev, newRecord]);
    
    // Update bottle water level (simulate drinking)
    setBottleStatus(prev => ({
      ...prev,
      waterLevel: Math.max(0, prev.waterLevel - (amount / 1000) * 10) // Rough calculation
    }));
  };

  const handleSyncBottle = () => {
    // Mock sync function - in real app would connect to actual bottle
    setBottleStatus(prev => ({
      ...prev,
      isConnected: !prev.isConnected
    }));
    
    setTimeout(() => {
      setBottleStatus(prev => ({
        ...prev,
        isConnected: true
      }));
    }, 2000);
  };

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Droplets className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">HydroTech</h1>
            <p className="text-gray-600">Your Smart Hydration Companion</p>
          </div>
          
          <UserProfileForm 
            profile={null} 
            onSave={setProfile} 
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <div className="max-w-md mx-auto bg-white min-h-screen shadow-xl">
        <div className="p-6 pb-24">
          {activeTab === 'dashboard' && (
            <HydrationDashboard
              profile={profile}
              records={records}
              onAddWater={handleAddWater}
              bottleStatus={bottleStatus}
            />
          )}
          
          {activeTab === 'bottle' && (
            <BottleControls
              bottleStatus={bottleStatus}
              notificationSettings={notificationSettings}
              onUpdateNotifications={setNotificationSettings}
              onSyncBottle={handleSyncBottle}
            />
          )}
          
          {activeTab === 'analytics' && (
            <Analytics
              records={records}
              profile={profile}
            />
          )}
          
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Droplets className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Profile Settings</h2>
              </div>
              
              <UserProfileForm
                profile={profile}
                onSave={setProfile}
              />
            </div>
          )}
        </div>
        
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
}

export default App;