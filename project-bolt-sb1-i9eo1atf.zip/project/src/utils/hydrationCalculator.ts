import { UserProfile } from '../types';

export function calculateDailyWaterGoal(profile: UserProfile): number {
  let baseWater = profile.weight * 35; // 35ml per kg as baseline
  
  // Adjust for activity level
  const activityMultipliers = {
    'sedentary': 1,
    'moderate': 1.1,
    'active': 1.2,
    'very-active': 1.3
  };
  
  baseWater *= activityMultipliers[profile.activityLevel];
  
  // Round to nearest 250ml
  return Math.round(baseWater / 250) * 250;
}

export function getHydrationStatus(consumed: number, goal: number): {
  percentage: number;
  status: 'poor' | 'fair' | 'good' | 'excellent';
  color: string;
} {
  const percentage = Math.min((consumed / goal) * 100, 100);
  
  if (percentage >= 90) {
    return { percentage, status: 'excellent', color: 'text-green-600' };
  } else if (percentage >= 70) {
    return { percentage, status: 'good', color: 'text-blue-600' };
  } else if (percentage >= 50) {
    return { percentage, status: 'fair', color: 'text-yellow-600' };
  } else {
    return { percentage, status: 'poor', color: 'text-red-600' };
  }
}

export function formatWaterAmount(ml: number): string {
  if (ml >= 1000) {
    return `${(ml / 1000).toFixed(1)}L`;
  }
  return `${ml}ml`;
}