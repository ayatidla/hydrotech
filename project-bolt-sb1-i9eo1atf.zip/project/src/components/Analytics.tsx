import React, { useMemo } from 'react';
import { HydrationRecord, UserProfile } from '../types';
import { formatWaterAmount } from '../utils/hydrationCalculator';
import { BarChart3, TrendingUp, Calendar, Award } from 'lucide-react';

interface AnalyticsProps {
  records: HydrationRecord[];
  profile: UserProfile;
}

export function Analytics({ records, profile }: AnalyticsProps) {
  const analytics = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date;
    }).reverse();

    const dailyData = last7Days.map(date => {
      const dayRecords = records.filter(record => 
        new Date(record.timestamp).toDateString() === date.toDateString()
      );
      const total = dayRecords.reduce((sum, record) => sum + record.amount, 0);
      const goalAchieved = total >= profile.dailyGoal;
      
      return {
        date,
        total,
        goalAchieved,
        percentage: (total / profile.dailyGoal) * 100
      };
    });

    const weeklyAverage = dailyData.reduce((sum, day) => sum + day.total, 0) / 7;
    const goalsAchieved = dailyData.filter(day => day.goalAchieved).length;
    const bestDay = dailyData.reduce((best, current) => 
      current.total > best.total ? current : best, dailyData[0]
    );

    return {
      dailyData,
      weeklyAverage,
      goalsAchieved,
      bestDay
    };
  }, [records, profile]);

  const maxAmount = Math.max(...analytics.dailyData.map(d => d.total), profile.dailyGoal);

  return (
    <div className="space-y-6 pb-20">
      {/* Weekly Summary */}
      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <BarChart3 className="w-6 h-6" />
          Weekly Summary
        </h2>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/20 rounded-lg p-4">
            <div className="text-2xl font-bold">{analytics.goalsAchieved}/7</div>
            <div className="text-blue-100 text-sm">Goals Achieved</div>
          </div>
          <div className="bg-white/20 rounded-lg p-4">
            <div className="text-2xl font-bold">{formatWaterAmount(Math.round(analytics.weeklyAverage))}</div>
            <div className="text-blue-100 text-sm">Daily Average</div>
          </div>
        </div>
      </div>

      {/* Daily Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-500" />
          7-Day Hydration Chart
        </h3>
        
        <div className="space-y-4">
          {analytics.dailyData.map((day, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">
                  {day.date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                </span>
                <span className={`font-medium ${day.goalAchieved ? 'text-green-600' : 'text-gray-600'}`}>
                  {formatWaterAmount(day.total)}
                </span>
              </div>
              
              <div className="relative">
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full transition-all duration-500 ${
                      day.goalAchieved ? 'bg-green-500' : 'bg-blue-500'
                    }`}
                    style={{ width: `${Math.min((day.total / maxAmount) * 100, 100)}%` }}
                  ></div>
                </div>
                
                {/* Goal line */}
                <div
                  className="absolute top-0 w-0.5 h-3 bg-red-400"
                  style={{ left: `${(profile.dailyGoal / maxAmount) * 100}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between text-xs text-gray-500">
                <span>0ml</span>
                <span className="text-red-500">Goal: {formatWaterAmount(profile.dailyGoal)}</span>
                <span>{formatWaterAmount(maxAmount)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Best Performance */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Award className="w-5 h-5 text-yellow-500" />
          Best Performance
        </h3>
        
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-gray-800">
                {formatWaterAmount(analytics.bestDay.total)}
              </div>
              <div className="text-sm text-gray-600">
                {analytics.bestDay.date.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-green-600">
                {Math.round(analytics.bestDay.percentage)}%
              </div>
              <div className="text-sm text-gray-600">of daily goal</div>
            </div>
          </div>
        </div>
      </div>

      {/* Hydration Tips */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">💡 Hydration Tips</h3>
        
        <div className="space-y-3">
          <div className="p-3 bg-blue-50 rounded-lg">
            <div className="text-sm font-medium text-blue-800">Start your day right</div>
            <div className="text-xs text-blue-600 mt-1">
              Drink a glass of water as soon as you wake up to kickstart your metabolism.
            </div>
          </div>
          
          <div className="p-3 bg-green-50 rounded-lg">
            <div className="text-sm font-medium text-green-800">Temperature matters</div>
            <div className="text-xs text-green-600 mt-1">
              Room temperature water is absorbed faster than cold water.
            </div>
          </div>
          
          <div className="p-3 bg-purple-50 rounded-lg">
            <div className="text-sm font-medium text-purple-800">Before meals</div>
            <div className="text-xs text-purple-600 mt-1">
              Drinking water 30 minutes before meals can aid digestion.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}