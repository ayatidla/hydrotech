import React, { useState } from 'react';
import { UserProfile } from '../types';
import { calculateDailyWaterGoal } from '../utils/hydrationCalculator';
import { User, Weight, Ruler, Activity } from 'lucide-react';

interface UserProfileFormProps {
  profile: UserProfile | null;
  onSave: (profile: UserProfile) => void;
  onCancel?: () => void;
}

export function UserProfileForm({ profile, onSave, onCancel }: UserProfileFormProps) {
  const [formData, setFormData] = useState<UserProfile>(
    profile || {
      name: '',
      age: 25,
      weight: 70,
      height: 170,
      activityLevel: 'moderate',
      dailyGoal: 2000
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedGoal = calculateDailyWaterGoal(formData);
    onSave({ ...formData, dailyGoal: calculatedGoal });
  };

  const handleInputChange = (field: keyof UserProfile, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-auto">
      <div className="text-center mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-cyan-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800">
          {profile ? 'Update Profile' : 'Set Up Your Profile'}
        </h2>
        <p className="text-gray-600 mt-2">
          Help us personalize your hydration goals
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Name
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => handleInputChange('name', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            placeholder="Enter your name"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Age
            </label>
            <input
              type="number"
              value={formData.age}
              onChange={(e) => handleInputChange('age', parseInt(e.target.value))}
              min="1"
              max="120"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Weight className="w-4 h-4 mr-1" />
              Weight (kg)
            </label>
            <input
              type="number"
              value={formData.weight}
              onChange={(e) => handleInputChange('weight', parseFloat(e.target.value))}
              min="30"
              max="300"
              step="0.1"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
        </div>

        <div>
          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
            <Ruler className="w-4 h-4 mr-1" />
            Height (cm)
          </label>
          <input
            type="number"
            value={formData.height}
            onChange={(e) => handleInputChange('height', parseInt(e.target.value))}
            min="100"
            max="250"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            required
          />
        </div>

        <div>
          <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
            <Activity className="w-4 h-4 mr-1" />
            Activity Level
          </label>
          <select
            value={formData.activityLevel}
            onChange={(e) => handleInputChange('activityLevel', e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
          >
            <option value="sedentary">Sedentary (desk job, minimal exercise)</option>
            <option value="moderate">Light Activity (exercise 1-3 times/week)</option>
            <option value="active">Moderately Active (exercise 3-5 times/week)</option>
            <option value="very-active">Very Active (exercise 6-7 times/week)</option>
          </select>
        </div>

        <div className="bg-blue-50 rounded-lg p-4">
          <p className="text-sm text-blue-800">
            <strong>Recommended daily goal:</strong> {calculateDailyWaterGoal(formData)}ml
          </p>
        </div>

        <div className="flex gap-3">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          )}
          <button
            type="submit"
            className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-lg hover:from-blue-600 hover:to-cyan-600 transition-all font-medium"
          >
            {profile ? 'Update Profile' : 'Save Profile'}
          </button>
        </div>
      </form>
    </div>
  );
}