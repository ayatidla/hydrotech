import React, { useState } from 'react';
import { BottleStatus, NotificationSettings } from '../types';
import { 
  Thermometer, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Bell, 
  BellOff,
  Bluetooth,
  Settings,
  RefreshCw
} from 'lucide-react';

interface BottleControlsProps {
  bottleStatus: BottleStatus;
  notificationSettings: NotificationSettings;
  onUpdateNotifications: (settings: NotificationSettings) => void;
  onSyncBottle: () => void;
}

export function BottleControls({ 
  bottleStatus, 
  notificationSettings, 
  onUpdateNotifications,
  onSyncBottle 
}: BottleControlsProps) {
  const [showSettings, setShowSettings] = useState(false);
  const [tempSettings, setTempSettings] = useState(notificationSettings);

  const handleSaveSettings = () => {
    onUpdateNotifications(tempSettings);
    setShowSettings(false);
  };

  const getTemperatureColor = (temp: number) => {
    if (temp < 10) return 'text-blue-600';
    if (temp < 25) return 'text-green-600';
    if (temp < 35) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTemperatureStatus = (temp: number) => {
    if (temp < 10) return 'Cold';
    if (temp < 25) return 'Cool';
    if (temp < 35) return 'Warm';
    return 'Hot';
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <Bluetooth className="w-6 h-6 text-blue-500" />
            HydroTech Bottle
          </h2>
          <button
            onClick={onSyncBottle}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <RefreshCw className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-4 h-4 rounded-full ${bottleStatus.isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="font-medium text-gray-800">
              {bottleStatus.isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          <div className="text-sm text-gray-500">
            Last sync: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Temperature Control */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Thermometer className="w-5 h-5 text-orange-500" />
          Temperature Monitor
        </h3>
        
        <div className="text-center">
          <div className={`text-6xl font-bold mb-2 ${getTemperatureColor(bottleStatus.temperature)}`}>
            {bottleStatus.temperature}°C
          </div>
          <div className={`text-lg font-medium ${getTemperatureColor(bottleStatus.temperature)}`}>
            {getTemperatureStatus(bottleStatus.temperature)}
          </div>
          
          <div className="mt-6 bg-gray-50 rounded-lg p-4">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Cold</span>
              <span>Perfect</span>
              <span>Hot</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 via-green-500 to-red-500 h-2 rounded-full relative"
              >
                <div 
                  className="absolute top-0 w-3 h-3 bg-gray-800 rounded-full transform -translate-y-0.5"
                  style={{ left: `${Math.min(Math.max((bottleStatus.temperature / 50) * 100, 0), 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
            {notificationSettings.soundEnabled ? <Bell className="w-5 h-5 text-blue-500" /> : <BellOff className="w-5 h-5 text-gray-400" />}
            Smart Reminders
          </h3>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {!showSettings ? (
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-700">Reminder Interval</span>
              <span className="font-medium text-gray-800">{notificationSettings.reminderInterval} min</span>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-700 flex items-center gap-2">
                {notificationSettings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                Sound Alerts
              </span>
              <div className={`w-12 h-6 rounded-full ${notificationSettings.soundEnabled ? 'bg-blue-500' : 'bg-gray-300'} relative transition-colors`}>
                <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${notificationSettings.soundEnabled ? 'left-6' : 'left-0.5'}`}></div>
              </div>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-700 flex items-center gap-2">
                <Smartphone className="w-4 h-4" />
                LCD Notifications
              </span>
              <div className={`w-12 h-6 rounded-full ${notificationSettings.lcdNotifications ? 'bg-blue-500' : 'bg-gray-300'} relative transition-colors`}>
                <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${notificationSettings.lcdNotifications ? 'left-6' : 'left-0.5'}`}></div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reminder Interval (minutes)
              </label>
              <select
                value={tempSettings.reminderInterval}
                onChange={(e) => setTempSettings(prev => ({ ...prev, reminderInterval: parseInt(e.target.value) }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={15}>15 minutes</option>
                <option value={30}>30 minutes</option>
                <option value={45}>45 minutes</option>
                <option value={60}>1 hour</option>
                <option value={90}>1.5 hours</option>
                <option value={120}>2 hours</option>
              </select>
            </div>

            <div className="space-y-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={tempSettings.soundEnabled}
                  onChange={(e) => setTempSettings(prev => ({ ...prev, soundEnabled: e.target.checked }))}
                  className="w-5 h-5 text-blue-500 rounded focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-gray-700">Enable sound alerts</span>
              </label>
              
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={tempSettings.lcdNotifications}
                  onChange={(e) => setTempSettings(prev => ({ ...prev, lcdNotifications: e.target.checked }))}
                  className="w-5 h-5 text-blue-500 rounded focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-gray-700">Show notifications on bottle LCD</span>
              </label>
              
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={tempSettings.personalizedMessages}
                  onChange={(e) => setTempSettings(prev => ({ ...prev, personalizedMessages: e.target.checked }))}
                  className="w-5 h-5 text-blue-500 rounded focus:ring-2 focus:ring-blue-500"
                />
                <span className="text-gray-700">Personalized motivational messages</span>
              </label>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setTempSettings(notificationSettings);
                  setShowSettings(false);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveSettings}
                className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-cyan-600 transition-all"
              >
                Save Settings
              </button>
            </div>
          </div>
        )}
      </div>

      {/* LCD Preview */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-green-500" />
          LCD Display Preview
        </h3>
        
        <div className="bg-gray-900 rounded-lg p-6 text-center">
          <div className="bg-green-400 text-black p-4 rounded font-mono text-sm">
            <div className="border border-green-600 p-3">
              <div className="text-xs mb-2">HydroTech Smart Bottle</div>
              <div className="text-lg font-bold mb-1">💧 {bottleStatus.waterLevel}%</div>
              <div className="text-xs mb-2">🌡️ {bottleStatus.temperature}°C</div>
              {notificationSettings.personalizedMessages && (
                <div className="text-xs mt-2 border-t border-green-600 pt-2">
                  "Stay hydrated, {tempSettings.personalizedMessages ? 'Champion' : 'User'}!"
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}