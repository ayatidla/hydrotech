import React, { useState, useEffect } from 'react';
import { ProgressRing } from './ProgressRing';
import { UserProfile, HydrationRecord, BottleStatus } from '../types';
import { getHydrationStatus, formatWaterAmount } from '../utils/hydrationCalculator';
import { 
  Droplets, 
  Thermometer, 
  Battery, 
  Plus, 
  Award, 
  TrendingUp,
  Clock,
  Target
} from 'lucide-react';

interface HydrationDashboardProps {
  profile: UserProfile;
  records: HydrationRecord[];
  onAddWater: (amount: number) => void;
  bottleStatus: BottleStatus;
}

export function HydrationDashboard({ 
  profile, 
  records, 
  onAddWater, 
  bottleStatus 
}: HydrationDashboardProps) {
  const [selectedAmount, setSelectedAmount] = useState(250);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate today's consumption
  const today = new Date().toDateString();
  const todayRecords = records.filter(record => 
    new Date(record.timestamp).toDateString() === today
  );
  const todayConsumption = todayRecords.reduce((sum, record) => sum + record.amount, 0);
  
  const hydrationStatus = getHydrationStatus(todayConsumption, profile.dailyGoal);
  
  // Quick add amounts
  const quickAmounts = [125, 250, 500, 750];

  // Calculate streak
  const calculateStreak = () => {
    let streak = 0;
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      const dayRecords = records.filter(record => 
        new Date(record.timestamp).toDateString() === checkDate.toDateString()
      );
      const dayTotal = dayRecords.reduce((sum, record) => sum + record.amount, 0);
      
      if (dayTotal >= profile.dailyGoal * 0.8) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  };

  const streak = calculateStreak();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-6 text-white">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">Hello, {profile.name}!</h1>
            <p className="text-blue-100 mt-1">
              {currentTime.toLocaleDateString('en-US', { 
                weekday: 'long', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{Math.round(hydrationStatus.percentage)}%</div>
            <div className="text-blue-100 text-sm">Daily Goal</div>
          </div>
        </div>
      </div>

      {/* Main Progress */}
      <div className="bg-white rounded-2xl shadow-lg p-6 text-center">
        <ProgressRing
          progress={hydrationStatus.percentage}
          size={200}
          strokeWidth={12}
          color="#0EA5E9"
        >
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-800">
              {formatWaterAmount(todayConsumption)}
            </div>
            <div className="text-sm text-gray-500">
              of {formatWaterAmount(profile.dailyGoal)}
            </div>
            <div className={`text-sm font-medium mt-1 ${hydrationStatus.color}`}>
              {hydrationStatus.status.charAt(0).toUpperCase() + hydrationStatus.status.slice(1)}
            </div>
          </div>
        </ProgressRing>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-xl shadow-md p-4">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <Award className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-800">{streak}</div>
              <div className="text-sm text-gray-500">Day Streak</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-800">{todayRecords.length}</div>
              <div className="text-sm text-gray-500">Drinks Today</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottle Status */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Droplets className="w-5 h-5 text-blue-500" />
          Bottle Status
        </h3>
        
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="bg-blue-50 rounded-full p-3 w-12 h-12 mx-auto mb-2">
              <Droplets className="w-6 h-6 text-blue-500" />
            </div>
            <div className="text-xl font-bold text-gray-800">{bottleStatus.waterLevel}%</div>
            <div className="text-xs text-gray-500">Water Level</div>
          </div>
          
          <div className="text-center">
            <div className="bg-orange-50 rounded-full p-3 w-12 h-12 mx-auto mb-2">
              <Thermometer className="w-6 h-6 text-orange-500" />
            </div>
            <div className="text-xl font-bold text-gray-800">{bottleStatus.temperature}°C</div>
            <div className="text-xs text-gray-500">Temperature</div>
          </div>
          
          <div className="text-center">
            <div className="bg-green-50 rounded-full p-3 w-12 h-12 mx-auto mb-2">
              <Battery className="w-6 h-6 text-green-500" />
            </div>
            <div className="text-xl font-bold text-gray-800">{bottleStatus.batteryLevel}%</div>
            <div className="text-xs text-gray-500">Battery</div>
          </div>
        </div>
        
        <div className="mt-4 flex items-center justify-center">
          <div className={`w-3 h-3 rounded-full mr-2 ${bottleStatus.isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
          <span className="text-sm text-gray-600">
            {bottleStatus.isConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
      </div>

      {/* Quick Add Water */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5 text-blue-500" />
          Log Water Intake
        </h3>
        
        <div className="grid grid-cols-4 gap-2 mb-4">
          {quickAmounts.map(amount => (
            <button
              key={amount}
              onClick={() => setSelectedAmount(amount)}
              className={`p-3 rounded-lg text-center transition-all ${
                selectedAmount === amount
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {amount}ml
            </button>
          ))}
        </div>
        
        <div className="mb-4">
          <input
            type="range"
            min="50"
            max="1000"
            step="25"
            value={selectedAmount}
            onChange={(e) => setSelectedAmount(parseInt(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="text-center mt-2 text-lg font-semibold text-gray-800">
            {selectedAmount}ml
          </div>
        </div>
        
        <button
          onClick={() => onAddWater(selectedAmount)}
          className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-3 rounded-lg hover:from-blue-600 hover:to-cyan-600 transition-all font-medium flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add Water
        </button>
      </div>

      {/* Recent Activity */}
      {todayRecords.length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-500" />
            Today's Activity
          </h3>
          
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {todayRecords.slice(-5).reverse().map(record => (
              <div key={record.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <Droplets className="w-4 h-4 text-blue-500" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">{record.amount}ml</div>
                    <div className="text-sm text-gray-500">
                      {new Date(record.timestamp).toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {record.temperature}°C
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}