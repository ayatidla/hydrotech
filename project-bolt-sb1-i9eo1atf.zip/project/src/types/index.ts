export interface UserProfile {
  name: string;
  age: number;
  weight: number; // in kg
  height: number; // in cm
  activityLevel: 'sedentary' | 'moderate' | 'active' | 'very-active';
  dailyGoal: number; // in ml
}

export interface HydrationRecord {
  id: string;
  timestamp: Date;
  amount: number; // in ml
  temperature: number; // in celsius
}

export interface BottleStatus {
  waterLevel: number; // percentage 0-100
  temperature: number; // in celsius
  batteryLevel: number; // percentage 0-100
  isConnected: boolean;
}

export interface NotificationSettings {
  reminderInterval: number; // in minutes
  soundEnabled: boolean;
  lcdNotifications: boolean;
  personalizedMessages: boolean;
}