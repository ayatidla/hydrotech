import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Droplets, User, Settings, Bell, Thermometer, Battery, Target, BarChart3, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import UserProfile from '@/components/UserProfile';
import Dashboard from '@/components/Dashboard';
import Notifications from '@/components/Notifications';
import BottleSettings from '@/components/BottleSettings';
import HydrationHistory from '@/components/HydrationHistory';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userProfile, setUserProfile] = useState({
    name: '',
    age: '',
    weight: '',
    height: '',
    activityLevel: 'moderate',
    gender: 'other',
    units: 'ml' 
  });
  const [bottleData, setBottleData] = useState({
    waterLevel: 75, // percentage
    temperature: 22, // celsius
    batteryLevel: 85, // percentage
    lastDrink: new Date().toISOString(),
    dailyGoal: 2000, // ml
    consumed: 1200, // ml
    reminders: true,
    soundEnabled: true,
    vibrationEnabled: true,
    reminderInterval: 30, // minutes
    temperatureUnit: 'celsius', // 'celsius' or 'fahrenheit'
    isConnected: true,
  });
  const [hydrationHistory, setHydrationHistory] = useState([]);

  // Charger les données depuis localStorage
  useEffect(() => {
    const savedProfile = localStorage.getItem('hydrotech-profile');
    const savedBottleData = localStorage.getItem('hydrotech-bottle');
    const savedHistory = localStorage.getItem('hydrotech-history');
    
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    }
    
    if (savedBottleData) {
      setBottleData(prev => ({ ...prev, ...JSON.parse(savedBottleData) }));
    }

    if (savedHistory) {
      setHydrationHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Sauvegarder les données
  useEffect(() => {
    localStorage.setItem('hydrotech-profile', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('hydrotech-bottle', JSON.stringify(bottleData));
  }, [bottleData]);

  useEffect(() => {
    localStorage.setItem('hydrotech-history', JSON.stringify(hydrationHistory));
  }, [hydrationHistory]);

  // Simulation des rappels d'hydratation
  useEffect(() => {
    if (!bottleData.reminders || !bottleData.isConnected) return;

    const interval = setInterval(() => {
      const now = new Date();
      const lastDrink = new Date(bottleData.lastDrink);
      const timeDiff = (now - lastDrink) / (1000 * 60); // en minutes

      if (timeDiff > bottleData.reminderInterval) { 
        let notificationMessage = "Il est temps de boire de l'eau ! Restez hydraté.";
        if (bottleData.soundEnabled) {
          // Simuler un son
          console.log("BEEP BEEP! Time to drink!");
        }
        if (bottleData.vibrationEnabled) {
          // Simuler une vibration
          if (navigator.vibrate) {
            navigator.vibrate(200); 
          }
          notificationMessage += " (Vibration)";
        }
        
        toast({
          title: "🔔 Rappel d'hydratation",
          description: notificationMessage,
          duration: 5000,
        });
        // Mettre à jour lastDrink pour éviter les rappels immédiats
        setBottleData(prev => ({ ...prev, lastDrink: new Date().toISOString() }));
      }
    }, 60000); // Vérifier chaque minute

    return () => clearInterval(interval);
  }, [bottleData.reminders, bottleData.soundEnabled, bottleData.vibrationEnabled, bottleData.lastDrink, bottleData.reminderInterval, bottleData.isConnected]);

  const tabs = [
    { id: 'dashboard', label: 'Tableau de bord', icon: Droplets },
    { id: 'history', label: 'Historique', icon: BarChart3 },
    { id: 'profile', label: 'Profil', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'settings', label: 'Paramètres', icon: Settings }
  ];

  const handleDrink = (amount) => {
    const newConsumed = Math.min(bottleData.consumed + amount, bottleData.dailyGoal * 2); // Allow overshooting goal
    const newWaterLevel = Math.max(bottleData.waterLevel - (amount / 20), 0); // Assuming 2000ml bottle, 250ml is 12.5%

    setBottleData(prev => ({
      ...prev,
      consumed: newConsumed,
      waterLevel: newWaterLevel,
      lastDrink: new Date().toISOString()
    }));

    // Add to history
    const today = new Date().toISOString().split('T')[0];
    setHydrationHistory(prevHistory => {
      const todayEntryIndex = prevHistory.findIndex(entry => entry.date === today);
      if (todayEntryIndex > -1) {
        const updatedHistory = [...prevHistory];
        updatedHistory[todayEntryIndex].consumed += amount;
        updatedHistory[todayEntryIndex].details.push({ time: new Date().toISOString(), amount });
        return updatedHistory;
      } else {
        return [...prevHistory, { date: today, consumed: amount, goal: bottleData.dailyGoal, details: [{ time: new Date().toISOString(), amount }] }];
      }
    });

    toast({
      title: "💧 Hydratation enregistrée",
      description: `Vous avez bu ${amount}${userProfile.units}. Continuez !`,
      duration: 3000,
    });
  };
  
  const convertToUserUnit = (valueMl) => {
    if (userProfile.units === 'oz') {
      return (valueMl / 29.5735).toFixed(1);
    }
    return valueMl;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-foreground">
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="glass-effect border-b border-white/10 sticky top-0 z-50"
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              className="flex items-center space-x-3"
              whileHover={{ scale: 1.05 }}
            >
              <div className="relative">
                <Droplets className="h-8 w-8 text-cyan-400" />
                <motion.div
                  className="absolute inset-0 bg-cyan-400/20 rounded-full blur-xl"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold gradient-text">HydroTech</h1>
                <p className="text-sm text-blue-300">Bouteille Intelligente</p>
              </div>
            </motion.div>

            <div className="hidden md:flex items-center space-x-6">
              <motion.div 
                className="flex items-center space-x-2 glass-effect px-3 py-2 rounded-lg"
                whileHover={{ scale: 1.05 }}
              >
                <Thermometer className="h-4 w-4 text-orange-400" />
                <span className="text-sm font-medium">
                  {bottleData.temperatureUnit === 'celsius' ? bottleData.temperature : (bottleData.temperature * 9/5 + 32).toFixed(0)}
                  °{bottleData.temperatureUnit === 'celsius' ? 'C' : 'F'}
                </span>
              </motion.div>
              
              <motion.div 
                className="flex items-center space-x-2 glass-effect px-3 py-2 rounded-lg"
                whileHover={{ scale: 1.05 }}
              >
                <Battery className="h-4 w-4 text-green-400" />
                <span className="text-sm font-medium">{bottleData.batteryLevel}%</span>
              </motion.div>

              <motion.div 
                className="flex items-center space-x-2 glass-effect px-3 py-2 rounded-lg"
                whileHover={{ scale: 1.05 }}
              >
                <Target className="h-4 w-4 text-purple-400" />
                <span className="text-sm font-medium">
                  {bottleData.dailyGoal > 0 ? Math.round((bottleData.consumed / bottleData.dailyGoal) * 100) : 0}%
                </span>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.header>

      <motion.nav 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="glass-effect border-b border-white/10"
      >
        <div className="container mx-auto px-4">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <motion.button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 md:px-6 md:py-4 rounded-t-lg transition-all duration-300 whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-b-2 border-cyan-400 text-cyan-400'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium text-sm md:text-base">{tab.label}</span>
                </motion.button>
              );
            })}
          </div>
        </div>
      </motion.nav>

      <main className="container mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'dashboard' && (
              <Dashboard 
                bottleData={bottleData} 
                userProfile={userProfile}
                onDrink={handleDrink}
                onUpdateBottleData={setBottleData}
                convertToUserUnit={convertToUserUnit}
              />
            )}
            
            {activeTab === 'history' && (
              <HydrationHistory 
                history={hydrationHistory} 
                userProfile={userProfile}
                convertToUserUnit={convertToUserUnit}
              />
            )}

            {activeTab === 'profile' && (
              <UserProfile 
                userProfile={userProfile}
                onUpdateProfile={setUserProfile}
                bottleData={bottleData}
                onUpdateBottleData={setBottleData}
                convertToUserUnit={convertToUserUnit}
              />
            )}
            
            {activeTab === 'notifications' && (
              <Notifications 
                bottleData={bottleData}
                userProfile={userProfile}
                onUpdateBottleData={setBottleData}
                convertToUserUnit={convertToUserUnit}
              />
            )}
            
            {activeTab === 'settings' && (
              <BottleSettings 
                bottleData={bottleData}
                userProfile={userProfile}
                onUpdateBottleData={setBottleData}
                onUpdateProfile={setUserProfile}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5, type: "spring" }}
      >
        <Button
          onClick={() => handleDrink(userProfile.units === 'oz' ? 236.59 : 250)} // Approx 8oz or 250ml
          className="h-16 w-16 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 shadow-2xl pulse-glow"
          size="icon"
          aria-label="Enregistrer une consommation d'eau"
        >
          <Droplets className="h-8 w-8" />
        </Button>
      </motion.div>

      <Toaster />
    </div>
  );
}

export default App;