import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, CalendarDays, Droplet, TrendingUp, TrendingDown, CheckCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const HydrationHistory = ({ history, userProfile, convertToUserUnit }) => {
  const [timePeriod, setTimePeriod] = useState('week'); // 'day', 'week', 'month'

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'short' });
  };
  
  const formatTime = (timeString) => {
    const date = new Date(timeString);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  const getFilteredHistory = () => {
    const today = new Date();
    today.setHours(0,0,0,0);

    return history
      .map(entry => ({ ...entry, dateObj: new Date(entry.date) }))
      .filter(entry => {
        if (timePeriod === 'day') {
          return entry.dateObj.toDateString() === today.toDateString();
        }
        if (timePeriod === 'week') {
          const oneWeekAgo = new Date(today);
          oneWeekAgo.setDate(today.getDate() - 6); // Include today + 6 previous days
          return entry.dateObj >= oneWeekAgo && entry.dateObj <= today;
        }
        if (timePeriod === 'month') {
          const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
          return entry.dateObj >= firstDayOfMonth && entry.dateObj <= today;
        }
        return true;
      })
      .sort((a, b) => b.dateObj - a.dateObj);
  };

  const filteredHistory = getFilteredHistory();

  const getAverageConsumption = () => {
    if (filteredHistory.length === 0) return 0;
    const total = filteredHistory.reduce((sum, entry) => sum + entry.consumed, 0);
    return Math.round(total / filteredHistory.length);
  };

  const averageConsumption = getAverageConsumption();
  const goalMetCount = filteredHistory.filter(entry => entry.consumed >= entry.goal).length;

  const chartMaxHeight = 200; // px
  const maxConsumptionInPeriod = Math.max(...filteredHistory.map(h => h.consumed), userProfile.dailyGoal || 2000);


  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold gradient-text mb-2">Historique d'hydratation</h2>
        <p className="text-gray-400">Suivez vos progrès au fil du temps</p>
      </motion.div>

      <Card className="glass-effect p-6">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
          <h3 className="text-xl font-semibold flex items-center">
            <CalendarDays className="h-5 w-5 mr-2 text-purple-400" />
            Votre consommation
          </h3>
          <div className="flex space-x-2">
            <Button size="sm" variant={timePeriod === 'day' ? 'default' : 'outline'} onClick={() => setTimePeriod('day')}>Jour</Button>
            <Button size="sm" variant={timePeriod === 'week' ? 'default' : 'outline'} onClick={() => setTimePeriod('week')}>Semaine</Button>
            <Button size="sm" variant={timePeriod === 'month' ? 'default' : 'outline'} onClick={() => setTimePeriod('month')}>Mois</Button>
          </div>
        </div>

        {filteredHistory.length === 0 ? (
          <div className="text-center py-10">
            <BarChart3 className="h-16 w-16 mx-auto text-gray-500 mb-4" />
            <p className="text-gray-400">Aucune donnée pour cette période.</p>
            <p className="text-sm text-gray-500">Commencez à enregistrer votre consommation !</p>
          </div>
        ) : (
          <>
            {/* Chart for week/month */}
            {(timePeriod === 'week' || timePeriod === 'month') && maxConsumptionInPeriod > 0 && (
              <div className="mb-8 h-[250px] glass-effect p-4 rounded-lg">
                <div className="flex justify-between items-end h-full gap-1 px-2">
                  {filteredHistory.slice(0, timePeriod === 'week' ? 7 : 30).reverse().map((entry, index) => {
                    const barHeight = (entry.consumed / maxConsumptionInPeriod) * chartMaxHeight;
                    const goalLinePosition = (entry.goal / maxConsumptionInPeriod) * chartMaxHeight;
                    return (
                      <div key={entry.date} className="flex-1 flex flex-col items-center relative group">
                        <div className="text-xs text-gray-400 mb-1 truncate w-full text-center">
                          {new Date(entry.date).toLocaleDateString('fr-FR', { day: '2-digit', month: timePeriod === 'month' ? '2-digit' : undefined })}
                        </div>
                        <div className="w-full h-[200px] flex items-end justify-center relative">
                           {entry.goal > 0 && (
                             <motion.div 
                                className="absolute w-full border-t-2 border-dashed border-green-500/50"
                                style={{ bottom: `${Math.min(goalLinePosition, chartMaxHeight - 2)}px` }}
                                initial={{ width: 0 }}
                                animate={{ width: '100%' }}
                                transition={{ delay: index * 0.05 + 0.5, duration: 0.5 }}
                              />
                           )}
                          <motion.div
                            className={`w-3/4 rounded-t-md ${entry.consumed >= entry.goal ? 'bg-gradient-to-b from-green-400 to-cyan-500' : 'bg-gradient-to-b from-blue-500 to-purple-600'}`}
                            initial={{ height: 0 }}
                            animate={{ height: `${Math.max(barHeight, 5)}px` }}
                            transition={{ delay: index * 0.05, duration: 0.5, type: 'spring', stiffness: 100 }}
                          />
                        </div>
                        <div className="absolute bottom-full mb-2 w-max p-2 bg-slate-800 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                          {formatDate(entry.date)}: {convertToUserUnit(entry.consumed)}{userProfile.units} / {convertToUserUnit(entry.goal)}{userProfile.units}
                        </div>
                      </div>
                    );
                  })}
                </div>
                 <div className="text-xs text-green-500/80 mt-1 text-right pr-2">- Objectif</div>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <Card className="glass-effect p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Droplet className="h-5 w-5 text-blue-400" />
                  <h4 className="font-semibold">Moyenne quotidienne</h4>
                </div>
                <p className="text-2xl font-bold gradient-text">
                  {convertToUserUnit(averageConsumption)}{userProfile.units}
                </p>
              </Card>
              <Card className="glass-effect p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <h4 className="font-semibold">Objectifs atteints</h4>
                </div>
                <p className="text-2xl font-bold gradient-text">
                  {goalMetCount} / {filteredHistory.length} jour{filteredHistory.length > 1 ? 's' : ''}
                </p>
              </Card>
            </div>
            
            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
              {filteredHistory.map(entry => (
                <motion.div
                  key={entry.date}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="glass-effect p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-lg">{formatDate(entry.date)}</h4>
                      <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        entry.consumed >= entry.goal ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                      }`}>
                        {entry.consumed >= entry.goal ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                        {convertToUserUnit(entry.consumed)}{userProfile.units} / {convertToUserUnit(entry.goal)}{userProfile.units}
                      </div>
                    </div>
                    {timePeriod === 'day' && entry.details && entry.details.length > 0 && (
                       <div className="mt-2 space-y-1 pl-4 border-l-2 border-cyan-500/30">
                         {entry.details.sort((a,b) => new Date(b.time) - new Date(a.time)).map((detail, idx) => (
                           <div key={idx} className="text-sm text-gray-300 flex justify-between">
                             <span>{formatTime(detail.time)}</span>
                             <span>+ {convertToUserUnit(detail.amount)}{userProfile.units}</span>
                           </div>
                         ))}
                       </div>
                    )}
                  </Card>
                </motion.div>
              ))}
            </div>
          </>
        )}
      </Card>
    </div>
  );
};

export default HydrationHistory;