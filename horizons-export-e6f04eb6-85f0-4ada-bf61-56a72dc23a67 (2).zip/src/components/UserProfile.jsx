import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Save, Calculator, Target, Activity, Droplet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';

const UserProfile = ({ userProfile, onUpdateProfile, bottleData, onUpdateBottleData, convertToUserUnit }) => {
  const [formData, setFormData] = useState(userProfile || {
    name: '',
    age: '',
    weight: '', // Store in kg
    height: '', // Store in cm
    activityLevel: 'moderate',
    gender: 'other',
    units: 'ml'
  });

  useEffect(() => {
    setFormData(userProfile);
  }, [userProfile]);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    let weightInKg = parseFloat(formData.weight);
    if (formData.units === 'oz' && userProfile.units === 'ml') { // If form is in oz but profile was ml, it means weight was entered in lbs
        // This case should not happen if units are handled correctly at input.
        // Assuming weight is always entered according to current formData.units
    } else if (formData.units === 'ml' && userProfile.units === 'oz') {
        // This case should not happen.
    }


    // Calculate daily goal in mL
    const weightForCalc = formData.units === 'oz' ? weightInKg * 0.453592 : weightInKg; // convert lbs to kg if needed
    const baseWater = weightForCalc * 35; // 35ml per kg
    
    const activityMultiplier = {
      low: 1,
      moderate: 1.2,
      high: 1.5,
      very_high: 1.8
    };
    
    const calculatedDailyGoalMl = Math.round(baseWater * activityMultiplier[formData.activityLevel]);
    
    onUpdateProfile(formData); // This updates units as well
    onUpdateBottleData(prev => ({
      ...prev,
      dailyGoal: calculatedDailyGoalMl // Always store goal in mL
    }));

    toast({
      title: "✅ Profil mis à jour",
      description: `Votre objectif d'hydratation est maintenant de ${convertToUserUnit(calculatedDailyGoalMl)}${formData.units} par jour.`,
      duration: 4000,
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleUnitChange = (newUnit) => {
    const oldUnit = formData.units;
    let newWeight = formData.weight;
    let newHeight = formData.height;

    if (oldUnit === 'ml' && newUnit === 'oz') { // ml to oz (kg to lbs, cm to inches)
      if (formData.weight) newWeight = (parseFloat(formData.weight) * 2.20462).toFixed(2); // kg to lbs
      if (formData.height) newHeight = (parseFloat(formData.height) / 2.54).toFixed(2); // cm to inches
    } else if (oldUnit === 'oz' && newUnit === 'ml') { // oz to ml (lbs to kg, inches to cm)
      if (formData.weight) newWeight = (parseFloat(formData.weight) / 2.20462).toFixed(2); // lbs to kg
      if (formData.height) newHeight = (parseFloat(formData.height) * 2.54).toFixed(2); // inches to cm
    }
    
    setFormData(prev => ({
      ...prev,
      units: newUnit,
      weight: newWeight,
      height: newHeight
    }));
  };


  const displayWeight = formData.weight;
  const displayHeight = formData.height;
  const weightUnitLabel = formData.units === 'ml' ? 'kg' : 'lbs';
  const heightUnitLabel = formData.units === 'ml' ? 'cm' : 'pouces';


  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold gradient-text mb-2">Profil Utilisateur</h2>
        <p className="text-gray-400">Personnalisez votre expérience d'hydratation</p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="glass-effect p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <User className="h-6 w-6 text-cyan-400" />
                <h3 className="text-xl font-semibold">Informations personnelles</h3>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant={formData.units === 'ml' ? 'default' : 'outline'} onClick={() => handleUnitChange('ml')}>ML</Button>
                <Button size="sm" variant={formData.units === 'oz' ? 'default' : 'outline'} onClick={() => handleUnitChange('oz')}>OZ</Button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nom complet</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Votre nom"
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="age">Âge</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => handleInputChange('age', e.target.value)}
                    placeholder="25"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="weight">Poids ({weightUnitLabel})</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={displayWeight}
                    onChange={(e) => handleInputChange('weight', e.target.value)}
                    placeholder={formData.units === 'ml' ? "70" : "154"}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="height">Taille ({heightUnitLabel})</Label>
                  <Input
                    id="height"
                    type="number"
                    value={displayHeight}
                    onChange={(e) => handleInputChange('height', e.target.value)}
                    placeholder={formData.units === 'ml' ? "175" : "69"}
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="gender">Genre</Label>
                <select
                  id="gender"
                  value={formData.gender}
                  onChange={(e) => handleInputChange('gender', e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="male">Homme</option>
                  <option value="female">Femme</option>
                  <option value="other">Autre</option>
                </select>
              </div>

              <div>
                <Label htmlFor="activity">Niveau d'activité</Label>
                <select
                  id="activity"
                  value={formData.activityLevel}
                  onChange={(e) => handleInputChange('activityLevel', e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="low">Faible (sédentaire)</option>
                  <option value="moderate">Modéré (exercice léger)</option>
                  <option value="high">Élevé (exercice régulier)</option>
                  <option value="very_high">Très élevé (athlète)</option>
                </select>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                disabled={!formData.weight || !formData.height || !formData.age}
              >
                <Save className="h-4 w-4 mr-2" />
                Sauvegarder le profil
              </Button>
            </form>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <Card className="glass-effect p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Calculator className="h-6 w-6 text-purple-400" />
              <h3 className="text-xl font-semibold">Calcul automatique</h3>
            </div>
            
            {formData.weight && (
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                  <span className="text-sm text-gray-300">Hydratation de base</span>
                  <span className="font-semibold text-purple-400">
                    {convertToUserUnit( (formData.units === 'oz' ? parseFloat(formData.weight) * 0.453592 : parseFloat(formData.weight)) * 35)}{formData.units}/jour
                  </span>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                  <span className="text-sm text-gray-300">Avec activité</span>
                  <span className="font-semibold text-cyan-400">
                    {convertToUserUnit(Math.round((formData.units === 'oz' ? parseFloat(formData.weight) * 0.453592 : parseFloat(formData.weight)) * 35 * {
                      low: 1,
                      moderate: 1.2,
                      high: 1.5,
                      very_high: 1.8
                    }[formData.activityLevel]))}{formData.units}/jour
                  </span>
                </div>
              </div>
            )}
          </Card>

          <Card className="glass-effect p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Target className="h-6 w-6 text-green-400" />
              <h3 className="text-xl font-semibold">Objectif actuel</h3>
            </div>
            
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">
                {convertToUserUnit(bottleData.dailyGoal)}{formData.units}
              </div>
              <p className="text-gray-400">par jour</p>
              
              <div className="mt-4 p-4 bg-green-500/10 rounded-lg border border-green-500/20">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-300">Progression aujourd'hui</span>
                  <span className="font-semibold text-green-400">
                    {bottleData.dailyGoal > 0 ? Math.round((bottleData.consumed / bottleData.dailyGoal) * 100) : 0}%
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                  <motion.div
                    className="bg-gradient-to-r from-green-400 to-cyan-400 h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${bottleData.dailyGoal > 0 ? Math.min((bottleData.consumed / bottleData.dailyGoal) * 100, 100) : 0}%` }}
                    transition={{ duration: 1, delay: 0.5 }}
                  />
                </div>
              </div>
            </div>
          </Card>

          <Card className="glass-effect p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Activity className="h-6 w-6 text-orange-400" />
              <h3 className="text-xl font-semibold">Conseils personnalisés</h3>
            </div>
            
            <div className="space-y-3">
              <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <p className="text-sm text-blue-300">
                  💡 Buvez un verre d'eau ({convertToUserUnit(250)}{formData.units}) dès le réveil.
                </p>
              </div>
              
              <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                <p className="text-sm text-green-300">
                  🏃‍♂️ Augmentez de {convertToUserUnit(500)}{formData.units} par heure d'exercice.
                </p>
              </div>
              
              <div className="p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                <p className="text-sm text-purple-300">
                  🌡️ Par temps chaud, ajoutez {convertToUserUnit(250)}{formData.units} supplémentaires.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default UserProfile;