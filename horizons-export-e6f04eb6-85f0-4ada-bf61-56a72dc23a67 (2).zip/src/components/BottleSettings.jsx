import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Settings, Volume2, VolumeX, Bell, BellOff, Thermometer, Battery, Wifi, WifiOff, Bluetooth, Smartphone, Save, RefreshCw, Power, PowerOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";


const BottleSettings = ({ bottleData, userProfile, onUpdateBottleData, onUpdateProfile }) => {
  const [settings, setSettings] = useState({
    soundEnabled: bottleData.soundEnabled,
    reminders: bottleData.reminders,
    reminderInterval: bottleData.reminderInterval,
    temperatureUnit: userProfile.units === 'oz' ? 'fahrenheit' : bottleData.temperatureUnit, // Sync with profile unit preference
    autoSync: true, // Assuming this is a general app setting, not bottle specific
    bluetoothEnabled: true, // Mocked, bottle specific
    wifiEnabled: bottleData.isConnected, // Reflects current connection state
    screenBrightness: 80, // Mocked, bottle specific
    soundVolume: 70, // Mocked, bottle specific
    vibrationEnabled: bottleData.vibrationEnabled,
  });

  useEffect(() => {
    setSettings(prev => ({
      ...prev,
      soundEnabled: bottleData.soundEnabled,
      reminders: bottleData.reminders,
      reminderInterval: bottleData.reminderInterval,
      temperatureUnit: userProfile.units === 'oz' ? 'fahrenheit' : bottleData.temperatureUnit,
      vibrationEnabled: bottleData.vibrationEnabled,
      wifiEnabled: bottleData.isConnected,
    }));
  }, [bottleData, userProfile.units]);


  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSliderChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value[0]
    }));
  };
  
  const handleTempUnitChange = (newUnit) => {
    handleSettingChange('temperatureUnit', newUnit);
    // Also update profile unit if they are linked, or bottleData if it stores this separately
    onUpdateBottleData(prev => ({ ...prev, temperatureUnit: newUnit }));
    if (newUnit === 'celsius') onUpdateProfile(prev => ({ ...prev, units: 'ml'}));
    if (newUnit === 'fahrenheit') onUpdateProfile(prev => ({ ...prev, units: 'oz'}));
  };


  const saveSettings = () => {
    onUpdateBottleData(prev => ({
      ...prev,
      soundEnabled: settings.soundEnabled,
      reminders: settings.reminders,
      reminderInterval: settings.reminderInterval,
      temperatureUnit: settings.temperatureUnit,
      vibrationEnabled: settings.vibrationEnabled,
      // Note: isConnected (wifiEnabled here) is more of a status than a setting from user.
    }));
    
    // If temperature unit changed, update profile unit preference
    if (settings.temperatureUnit === 'celsius' && userProfile.units !== 'ml') {
      onUpdateProfile(prev => ({ ...prev, units: 'ml' }));
    } else if (settings.temperatureUnit === 'fahrenheit' && userProfile.units !== 'oz') {
      onUpdateProfile(prev => ({ ...prev, units: 'oz' }));
    }


    toast({
      title: "✅ Paramètres sauvegardés",
      description: "Vos préférences ont été mises à jour avec succès.",
      duration: 3000,
    });
  };

  const resetToDefaults = () => {
    const defaultSettings = {
      soundEnabled: true,
      reminders: true,
      reminderInterval: 30,
      temperatureUnit: 'celsius',
      autoSync: true,
      bluetoothEnabled: true,
      wifiEnabled: true,
      screenBrightness: 80,
      soundVolume: 70,
      vibrationEnabled: true,
    };
    setSettings(defaultSettings);
    onUpdateBottleData(prev => ({
      ...prev,
      soundEnabled: defaultSettings.soundEnabled,
      reminders: defaultSettings.reminders,
      reminderInterval: defaultSettings.reminderInterval,
      temperatureUnit: defaultSettings.temperatureUnit,
      vibrationEnabled: defaultSettings.vibrationEnabled,
      isConnected: defaultSettings.wifiEnabled,
    }));
    onUpdateProfile(prev => ({ ...prev, units: 'ml' }));


    toast({
      title: "🔄 Paramètres réinitialisés",
      description: "Tous les paramètres ont été remis aux valeurs par défaut.",
      duration: 3000,
    });
  };

  const simulateSync = () => {
    toast({
      title: "🔄 Synchronisation...",
      description: "Synchronisation avec votre bouteille HydroTech en cours.",
      duration: 2000,
    });

    setTimeout(() => {
      onUpdateBottleData(prev => ({...prev, isConnected: true})); // Simulate successful sync
      toast({
        title: "✅ Synchronisation terminée",
        description: "Vos données ont été synchronisées avec succès.",
        duration: 3000,
      });
    }, 2000);
  };
  
  const toggleConnection = () => {
    onUpdateBottleData(prev => ({...prev, isConnected: !prev.isConnected}));
    toast({
      title: bottleData.isConnected ? "🔌 Déconnexion..." : "🔗 Connexion...",
      description: bottleData.isConnected ? "Déconnexion de la bouteille en cours." : "Tentative de connexion à la bouteille.",
      duration: 1500
    });
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold gradient-text mb-2">Paramètres de la bouteille</h2>
        <p className="text-gray-400">Personnalisez votre expérience HydroTech</p>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="glass-effect p-6">
            <h3 className="text-xl font-semibold mb-6 flex items-center">
              <Bell className="h-5 w-5 mr-2 text-blue-400" />
              Notifications et sons
            </h3>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <Label className="text-base font-medium">Rappels d'hydratation</Label>
                <Button
                  onClick={() => handleSettingChange('reminders', !settings.reminders)}
                  variant={settings.reminders ? "default" : "outline"}
                  size="sm"
                  className={settings.reminders ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  {settings.reminders ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                </Button>
              </div>
              
              {settings.reminders && (
                <div>
                  <Label htmlFor="reminderInterval" className="text-base font-medium mb-2 block">Intervalle des rappels (minutes)</Label>
                   <Select value={settings.reminderInterval.toString()} onValueChange={(val) => handleSettingChange('reminderInterval', parseInt(val))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Choisir intervalle" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="45">45 minutes</SelectItem>
                      <SelectItem value="60">60 minutes</SelectItem>
                      <SelectItem value="90">90 minutes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex items-center justify-between">
                <Label className="text-base font-medium">Sons activés</Label>
                <Button
                  onClick={() => handleSettingChange('soundEnabled', !settings.soundEnabled)}
                  variant={settings.soundEnabled ? "default" : "outline"}
                  size="sm"
                  className={settings.soundEnabled ? 'bg-green-600 hover:bg-green-700' : ''}
                >
                  {settings.soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>

              <div>
                <Label className="text-base font-medium mb-3 block">Volume sonore</Label>
                <Slider
                  value={[settings.soundVolume]}
                  onValueChange={(value) => handleSliderChange('soundVolume', value)}
                  max={100}
                  step={10}
                  className="w-full"
                  disabled={!settings.soundEnabled}
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>Silencieux</span>
                  <span>{settings.soundVolume}%</span>
                  <span>Maximum</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-base font-medium">Vibrations</Label>
                <Button
                  onClick={() => handleSettingChange('vibrationEnabled', !settings.vibrationEnabled)}
                  variant={settings.vibrationEnabled ? "default" : "outline"}
                  size="sm"
                  className={settings.vibrationEnabled ? 'bg-purple-600 hover:bg-purple-700' : ''}
                >
                  <Smartphone className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-effect p-6">
            <h3 className="text-xl font-semibold mb-6 flex items-center">
              <Smartphone className="h-5 w-5 mr-2 text-cyan-400" />
              Affichage et connectivité
            </h3>

            <div className="space-y-6">
              <div>
                <Label className="text-base font-medium mb-3 block">Luminosité de l'écran LCD</Label>
                <Slider
                  value={[settings.screenBrightness]}
                  onValueChange={(value) => handleSliderChange('screenBrightness', value)}
                  max={100}
                  step={10}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>Faible</span>
                  <span>{settings.screenBrightness}%</span>
                  <span>Élevée</span>
                </div>
              </div>

              <div>
                <Label className="text-base font-medium mb-3 block">Unité de température</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={() => handleTempUnitChange('celsius')}
                    variant={settings.temperatureUnit === 'celsius' ? "default" : "outline"}
                    className={settings.temperatureUnit === 'celsius' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                  >
                    °C (Celsius)
                  </Button>
                  <Button
                    onClick={() => handleTempUnitChange('fahrenheit')}
                    variant={settings.temperatureUnit === 'fahrenheit' ? "default" : "outline"}
                    className={settings.temperatureUnit === 'fahrenheit' ? 'bg-orange-600 hover:bg-orange-700' : ''}
                  >
                    °F (Fahrenheit)
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-base font-medium">Bluetooth</Label>
                 <Button
                  onClick={() => handleSettingChange('bluetoothEnabled', !settings.bluetoothEnabled)}
                  variant={settings.bluetoothEnabled ? "default" : "outline"}
                  size="sm"
                  className={settings.bluetoothEnabled ? 'bg-blue-600 hover:bg-blue-700' : ''}
                >
                  <Bluetooth className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-base font-medium">Connexion (WiFi/App)</Label>
                <Button
                  onClick={toggleConnection}
                  variant={bottleData.isConnected ? "default" : "outline"}
                  size="sm"
                  className={bottleData.isConnected ? 'bg-green-600 hover:bg-green-700' : 'border-red-500 text-red-500 hover:bg-red-500/10'}
                >
                  {bottleData.isConnected ? <Wifi className="h-4 w-4" /> : <WifiOff className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="glass-effect p-6">
          <h3 className="text-xl font-semibold mb-6 flex items-center">
            <Battery className="h-5 w-5 mr-2 text-green-400" />
            État de la bouteille
          </h3>

          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <Thermometer className="h-8 w-8 mx-auto mb-2 text-blue-400" />
              <div className="text-2xl font-bold text-blue-400">
                {settings.temperatureUnit === 'celsius' ? bottleData.temperature : (bottleData.temperature * 9/5 + 32).toFixed(0)}°{settings.temperatureUnit === 'celsius' ? 'C' : 'F'}
              </div>
              <div className="text-sm text-gray-400">Température</div>
            </div>

            <div className="text-center p-4 bg-green-500/10 rounded-lg border border-green-500/20">
              <Battery className="h-8 w-8 mx-auto mb-2 text-green-400" />
              <div className="text-2xl font-bold text-green-400">{bottleData.batteryLevel}%</div>
              <div className="text-sm text-gray-400">Batterie</div>
            </div>
            
            <div className="text-center p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
              {bottleData.isConnected ? 
                <Wifi className="h-8 w-8 mx-auto mb-2 text-cyan-400" /> : 
                <WifiOff className="h-8 w-8 mx-auto mb-2 text-red-400" />
              }
              <div className={`text-2xl font-bold ${bottleData.isConnected ? 'text-cyan-400' : 'text-red-400'}`}>
                {bottleData.isConnected ? 'Connecté' : 'Déconnecté'}
              </div>
              <div className="text-sm text-gray-400">État connexion</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={saveSettings}
              className="bg-gradient-to-r from-green-500 to-cyan-500 hover:from-green-600 hover:to-cyan-600"
            >
              <Save className="h-4 w-4 mr-2" />
              Sauvegarder
            </Button>

            <Button
              onClick={simulateSync}
              variant="outline"
              className="border-blue-500/30 hover:bg-blue-500/10"
              disabled={!bottleData.isConnected}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Synchroniser
            </Button>

            <Button
              onClick={resetToDefaults}
              variant="outline"
              className="border-orange-500/30 hover:bg-orange-500/10"
            >
              Réinitialiser
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default BottleSettings;