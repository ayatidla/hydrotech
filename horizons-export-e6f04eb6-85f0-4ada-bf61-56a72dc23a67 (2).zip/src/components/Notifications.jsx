import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, Clock, Droplets, Volume2, VolumeX, Smartphone, AlertCircle, CheckCircle, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';

const Notifications = ({ bottleData, userProfile, onUpdateBottleData, convertToUserUnit }) => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const generateNotifications = () => {
      const now = new Date();
      const lastDrink = new Date(bottleData.lastDrink);
      const timeSinceLastDrink = (now - lastDrink) / (1000 * 60);
      
      const newNotifications = [];

      if (timeSinceLastDrink > bottleData.reminderInterval && bottleData.reminders) {
        newNotifications.push({
          id: `reminder-${Date.now()}`,
          type: 'reminder',
          title: 'Rappel d\'hydratation',
          message: `Il est temps de boire de l'eau ! Buvez environ ${convertToUserUnit(250)}${userProfile.units}.`,
          time: new Date().toISOString(),
          priority: 'high',
          read: false
        });
      }

      if (bottleData.waterLevel < 20) {
        newNotifications.push({
          id: `water-${Date.now()}`,
          type: 'warning',
          title: 'Niveau d\'eau bas',
          message: `Votre bouteille est à ${bottleData.waterLevel}%. Pensez à la remplir.`,
          time: new Date().toISOString(),
          priority: 'medium',
          read: false
        });
      }

      if (bottleData.batteryLevel < 20) {
        newNotifications.push({
          id: `battery-${Date.now()}`,
          type: 'battery',
          title: 'Batterie faible',
          message: `La batterie de votre HydroTech est à ${bottleData.batteryLevel}%. Rechargez bientôt.`,
          time: new Date().toISOString(),
          priority: 'medium',
          read: false
        });
      }
      
      if (!bottleData.isConnected) {
        newNotifications.push({
          id: `connection-${Date.now()}`,
          type: 'connection',
          title: 'Bouteille déconnectée',
          message: 'La connexion avec votre HydroTech a été perdue.',
          time: new Date().toISOString(),
          priority: 'high',
          read: false
        });
      }


      if (bottleData.dailyGoal > 0 && (bottleData.consumed / bottleData.dailyGoal) >= 1 && !notifications.find(n => n.type === 'success' && new Date(n.time).toDateString() === new Date().toDateString())) {
        newNotifications.push({
          id: `goal-${Date.now()}`,
          type: 'success',
          title: 'Objectif atteint !',
          message: `Félicitations ! Vous avez atteint votre objectif de ${convertToUserUnit(bottleData.dailyGoal)}${userProfile.units}.`,
          time: new Date().toISOString(),
          priority: 'low',
          read: false
        });
      }
      
      // Keep some old notifications for display
      const historicalNotifications = [
        { id: 'hist-1', type: 'info', title: 'Bienvenue sur HydroTech!', message: 'Configurez votre profil pour commencer.', time: new Date(Date.now() - 86400000 * 2).toISOString(), priority: 'low', read: true },
        { id: 'hist-2', type: 'reminder', title: 'Pensez à boire', message: 'Un rappel amical pour rester hydraté.', time: new Date(Date.now() - 3600000 * 5).toISOString(), priority: 'medium', read: true },
      ];

      setNotifications(prev => {
        const existingIds = new Set(prev.map(n => n.id));
        const uniqueNew = newNotifications.filter(n => !existingIds.has(n.id));
        return [...uniqueNew, ...prev, ...historicalNotifications.filter(hn => !existingIds.has(hn.id) && !uniqueNew.find(un => un.id === hn.id))].slice(0, 10); // Limit to 10 notifications
      });
    };

    generateNotifications();
    const intervalId = setInterval(generateNotifications, 60000); // Check for new notifications every minute
    return () => clearInterval(intervalId);

  }, [bottleData, userProfile.units, convertToUserUnit]);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'reminder': return <Bell className="h-5 w-5 text-blue-400" />;
      case 'warning': return <AlertCircle className="h-5 w-5 text-orange-400" />;
      case 'battery': return <AlertCircle className="h-5 w-5 text-red-400" />;
      case 'success': return <CheckCircle className="h-5 w-5 text-green-400" />;
      case 'connection': return <WifiOff className="h-5 w-5 text-yellow-400" />;
      default: return <Bell className="h-5 w-5 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-red-500/30 bg-red-500/10';
      case 'medium': return 'border-orange-500/30 bg-orange-500/10';
      case 'low': return 'border-green-500/30 bg-green-500/10';
      default: return 'border-gray-500/30 bg-gray-500/10';
    }
  };

  const markAsRead = (id) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };
  
  const toggleSound = () => {
    const newSoundEnabled = !bottleData.soundEnabled;
    onUpdateBottleData(prev => ({ ...prev, soundEnabled: newSoundEnabled }));
    toast({
      title: newSoundEnabled ? "🔊 Son activé" : "🔇 Son désactivé",
      description: newSoundEnabled ? "Les rappels sonores sont activés" : "Les rappels sonores sont désactivés",
      duration: 3000,
    });
  };

  const testNotification = () => {
    toast({
      title: "🔔 Test de notification",
      description: "Ceci est un test de notification HydroTech.",
      duration: 4000,
    });
    if (bottleData.soundEnabled) console.log("BEEP BEEP! Test sound!");
    if (bottleData.vibrationEnabled && navigator.vibrate) navigator.vibrate(200);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold gradient-text mb-2">Centre de notifications</h2>
        <p className="text-gray-400">Gérez vos rappels et alertes HydroTech</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="glass-effect p-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Volume2 className="h-5 w-5 mr-2 text-purple-400" />
            Paramètres de notification
          </h3>
          
          <div className="grid md:grid-cols-3 gap-4">
            <Button
              onClick={toggleSound}
              variant={bottleData.soundEnabled ? "default" : "outline"}
              className={`h-16 ${bottleData.soundEnabled ? 
                'bg-gradient-to-r from-green-500 to-cyan-500' : 
                'border-gray-500/30 hover:bg-gray-500/10'
              }`}
            >
              <div className="text-center">
                {bottleData.soundEnabled ? <Volume2 className="h-6 w-6 mx-auto mb-1" /> : <VolumeX className="h-6 w-6 mx-auto mb-1" />}
                <span className="text-sm">{bottleData.soundEnabled ? 'Son activé' : 'Son désactivé'}</span>
              </div>
            </Button>

            <Button
              onClick={testNotification}
              variant="outline"
              className="h-16 border-blue-500/30 hover:bg-blue-500/10"
            >
              <div className="text-center">
                <Bell className="h-6 w-6 mx-auto mb-1 text-blue-400" />
                <span className="text-sm">Test notification</span>
              </div>
            </Button>

            <div className="h-16 glass-effect rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-400">{unreadCount}</div>
                <div className="text-sm text-gray-400">Non lues</div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        <h3 className="text-xl font-semibold flex items-center">
          <Smartphone className="h-5 w-5 mr-2 text-cyan-400" />
          Notifications récentes
        </h3>

        {notifications.length === 0 ? (
          <Card className="glass-effect p-8 text-center">
            <Bell className="h-12 w-12 mx-auto mb-4 text-gray-500" />
            <p className="text-gray-400">Aucune notification pour le moment</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {notifications.sort((a,b) => new Date(b.time) - new Date(a.time)).map((notification, index) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => markAsRead(notification.id)}
                className={`cursor-pointer transition-all duration-300 ${
                  notification.read ? 'opacity-60 hover:opacity-80' : 'opacity-100'
                }`}
              >
                <Card className={`glass-effect p-4 border ${getPriorityColor(notification.priority)} ${
                  !notification.read ? 'ring-1 ring-cyan-400/50 shadow-lg shadow-cyan-500/10' : ''
                }`}>
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 mt-1">
                      {getNotificationIcon(notification.type)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className={`font-medium ${!notification.read ? 'text-white' : 'text-gray-300'}`}>
                          {notification.title}
                        </h4>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-gray-400">
                            {new Date(notification.time).toLocaleTimeString('fr-FR', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-gray-400 mt-1">
                        {notification.message}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="glass-effect p-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Smartphone className="h-5 w-5 mr-2 text-green-400" />
            Affichage LCD de la bouteille
          </h3>
          
          <div className="bg-black rounded-lg p-6 border-2 border-green-600 font-mono">
            <div className="text-green-400 space-y-2">
              <div className="text-center text-lg font-bold border-b border-green-600 pb-2">
                HYDROTECH v2.1 {bottleData.isConnected ? <Wifi className="inline h-4 w-4 ml-2 text-green-400" /> : <WifiOff className="inline h-4 w-4 ml-2 text-red-400" />}
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div>TEMP: {bottleData.temperatureUnit === 'celsius' ? bottleData.temperature : (bottleData.temperature * 9/5 + 32).toFixed(0)}°{bottleData.temperatureUnit === 'celsius' ? 'C' : 'F'}</div>
                  <div>NIVEAU: {bottleData.waterLevel}%</div>
                </div>
                <div>
                  <div>BATT: {bottleData.batteryLevel}%</div>
                  <div>OBJ: {bottleData.dailyGoal > 0 ? Math.round((bottleData.consumed / bottleData.dailyGoal) * 100) : 0}%</div>
                </div>
              </div>
              
              <div className="border-t border-green-600 pt-2">
                <div className="text-center">
                  {unreadCount > 0 ? (
                    <div className="animate-pulse">
                      ⚠ {unreadCount} NOTIFICATION{unreadCount > 1 ? 'S' : ''}
                    </div>
                  ) : (
                    <div>✓ TOUT VA BIEN</div>
                  )}
                </div>
              </div>
              
              <div className="text-center text-xs">
                {new Date().toLocaleTimeString('fr-FR')}
              </div>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default Notifications;