import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Droplets, Thermometer, Battery, Clock, Target, TrendingUp, Zap, Waves, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const Dashboard = ({ bottleData, userProfile, onDrink, onUpdateBottleData, convertToUserUnit }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const progressPercentage = bottleData.dailyGoal > 0 ? Math.min((bottleData.consumed / bottleData.dailyGoal) * 100, 100) : 0;
  const waterLevelHeight = Math.max(bottleData.waterLevel, 5);

  const drinkAmountsMl = [100, 250, 500];

  const getTimeBasedGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return "Bonjour";
    if (hour < 18) return "Bon après-midi";
    return "Bonsoir";
  };

  const getHydrationStatus = () => {
    if (progressPercentage >= 100) return { text: "Objectif atteint !", color: "text-green-400", bg: "bg-green-500/10" };
    if (progressPercentage >= 75) return { text: "Excellent progrès", color: "text-cyan-400", bg: "bg-cyan-500/10" };
    if (progressPercentage >= 50) return { text: "Bon rythme", color: "text-blue-400", bg: "bg-blue-500/10" };
    if (progressPercentage >= 25) return { text: "Continuez !", color: "text-yellow-400", bg: "bg-yellow-500/10" };
    return { text: "Commencez à boire", color: "text-orange-400", bg: "bg-orange-500/10" };
  };

  const status = getHydrationStatus();
  const displayTemperature = bottleData.temperatureUnit === 'celsius' ? bottleData.temperature : (bottleData.temperature * 9/5 + 32).toFixed(0);
  const temperatureSymbol = bottleData.temperatureUnit === 'celsius' ? 'C' : 'F';

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold gradient-text mb-2">
          {getTimeBasedGreeting()}{userProfile?.name ? `, ${userProfile.name}` : ''} !
        </h2>
        <p className="text-gray-400">Suivez votre hydratation en temps réel</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="glass-effect p-6 relative overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <Target className="h-8 w-8 text-cyan-400" />
              <span className={`text-sm font-medium px-2 py-1 rounded-full ${status.bg} ${status.color}`}>
                {status.text}
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-400">Objectif quotidien</span>
                <span className="text-sm font-medium">{Math.round(progressPercentage)}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <motion.div
                  className="bg-gradient-to-r from-cyan-400 to-blue-500 h-3 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                />
              </div>
              <div className="text-center">
                <span className="text-2xl font-bold text-white">{convertToUserUnit(bottleData.consumed)}</span>
                <span className="text-gray-400">/{convertToUserUnit(bottleData.dailyGoal)}{userProfile.units}</span>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-effect p-6">
            <div className="flex items-center justify-between mb-4">
              <Waves className="h-8 w-8 text-blue-400" />
              <span className="text-sm text-gray-400">Niveau bouteille</span>
            </div>
            <div className="relative h-32 w-16 mx-auto bg-gray-700 rounded-full overflow-hidden">
              <motion.div
                className="absolute bottom-0 w-full water-level rounded-full"
                initial={{ height: 0 }}
                animate={{ height: `${waterLevelHeight}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xs font-bold text-white z-10">{bottleData.waterLevel}%</span>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="glass-effect p-6">
            <div className="flex items-center justify-between mb-4">
              <Thermometer className="h-8 w-8 text-orange-400" />
              <span className="text-sm text-gray-400">Température</span>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-400 mb-2">
                {displayTemperature}°{temperatureSymbol}
              </div>
              <div className={`text-sm px-2 py-1 rounded-full ${
                bottleData.temperature < 10 ? 'bg-blue-500/20 text-blue-400' :
                bottleData.temperature > 25 ? 'bg-red-500/20 text-red-400' :
                'bg-green-500/20 text-green-400'
              }`}>
                {bottleData.temperature < 10 ? 'Froid' :
                 bottleData.temperature > 25 ? 'Chaud' : 'Idéal'}
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="glass-effect p-6">
            <div className="flex items-center justify-between mb-4">
              <Battery className="h-8 w-8 text-green-400" />
              <span className="text-sm text-gray-400">Batterie</span>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-400 mb-2">
                {bottleData.batteryLevel}%
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <motion.div
                  className={`h-2 rounded-full ${
                    bottleData.batteryLevel > 50 ? 'bg-green-400' :
                    bottleData.batteryLevel > 20 ? 'bg-yellow-400' : 'bg-red-400'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${bottleData.batteryLevel}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
              <div className="mt-2 flex items-center justify-center space-x-2">
                {bottleData.isConnected ? <Wifi className="h-4 w-4 text-cyan-400" /> : <WifiOff className="h-4 w-4 text-red-400" />}
                <span className={`text-xs ${bottleData.isConnected ? 'text-cyan-400' : 'text-red-400'}`}>
                  {bottleData.isConnected ? 'Connecté' : 'Déconnecté'}
                </span>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="glass-effect p-8">
            <h3 className="text-xl font-semibold mb-6 text-center">Votre HydroTech</h3>
            
            <div className="relative mx-auto w-32 h-64 bg-gradient-to-b from-gray-600 to-gray-800 rounded-3xl border-4 border-gray-500 overflow-hidden">
              <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-20 h-8 bg-green-900 rounded border border-green-600 flex items-center justify-center">
                <span className="text-green-400 text-xs font-mono">{displayTemperature}°{temperatureSymbol}</span>
              </div>
              
              <motion.div
                className="absolute bottom-2 left-2 right-2 water-level rounded-2xl"
                initial={{ height: 0 }}
                animate={{ height: `${waterLevelHeight * 0.9}%` }}
                transition={{ duration: 2, ease: "easeOut" }}
              />
              
              <div className="absolute top-16 left-2 w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
              <div className="absolute top-16 right-2 w-2 h-2 bg-red-400 rounded-full animate-pulse" />
              
              <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 w-6 h-3 border border-white rounded-sm">
                <motion.div
                  className={`h-full rounded-sm ${
                    bottleData.batteryLevel > 50 ? 'bg-green-400' :
                    bottleData.batteryLevel > 20 ? 'bg-yellow-400' : 'bg-red-400'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${bottleData.batteryLevel}%` }}
                  transition={{ duration: 1, delay: 1 }}
                />
              </div>
            </div>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-400 mb-2">Dernière consommation</p>
              <p className="text-lg font-medium">
                {new Date(bottleData.lastDrink).toLocaleTimeString('fr-FR', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </p>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="space-y-6"
        >
          <Card className="glass-effect p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Zap className="h-5 w-5 mr-2 text-yellow-400" />
              Actions rapides
            </h3>
            
            <div className="grid grid-cols-3 gap-3 mb-6">
              {drinkAmountsMl.map((amountMl) => (
                <Button
                  key={amountMl}
                  onClick={() => onDrink(amountMl)}
                  className="h-16 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border border-cyan-500/30"
                  variant="outline"
                >
                  <div className="text-center">
                    <Droplets className="h-6 w-6 mx-auto mb-1 text-cyan-400" />
                    <span className="text-sm font-medium">{convertToUserUnit(amountMl)}{userProfile.units}</span>
                  </div>
                </Button>
              ))}
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => onUpdateBottleData(prev => ({ ...prev, waterLevel: 100 }))}
                className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
              >
                Remplir la bouteille
              </Button>
              
              <Button
                onClick={() => onUpdateBottleData(prev => ({ 
                  ...prev, 
                  temperature: Math.floor(Math.random() * 20) + 15 
                }))}
                variant="outline"
                className="w-full border-orange-500/30 hover:bg-orange-500/10"
              >
                Actualiser température
              </Button>
            </div>
          </Card>

          <Card className="glass-effect p-6">
            <h3 className="text-xl font-semibold mb-4">Notifications LCD</h3>
            
            <div className="space-y-3">
              <div className="notification-pulse p-3 rounded-lg border">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-sm">Rappel d'hydratation {bottleData.reminders ? 'activé' : 'désactivé'}</span>
                </div>
              </div>
              
              <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-blue-400" />
                  <span className="text-sm">Prochain rappel dans {bottleData.reminderInterval} min</span>
                </div>
              </div>
              
              <div className="p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4 text-purple-400" />
                  <span className="text-sm">Objectif quotidien: {Math.round(progressPercentage)}%</span>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;